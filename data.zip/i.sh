#!/system/xbin/bash
#!/bin/bash
#version 1.0

clear
# Variables
b='\033[1m'
u='\033[4m'
bl='\E[30m'
r='\E[31m'
g='\E[32m'
bu='\E[34m'
m='\E[35m'
c='\E[36m'
w='\E[37m'
endc='\E[0m'
enda='\033[0m'
blue='\e[1;34m'
cyan='\e[1;36m'
red='\e[1;31m'

sleep 1
###################################################
# CTRL + C
###################################################
trap ctrl_c INT
ctrl_c() {
clear
clear
sleep 1
exit
}


lagi=1
while [ $lagi -lt 6 ];
do
clear
echo ""
echo "
\n
\033[1;32m    <=====================\033[1;36m[]\033[1;32m====================>
\033[1;32m    <=====\033[1;36m[       \033[1;35mTools By Moreno77     \033[1;36m  ]\033[1;32m=====>
\033[1;32m    <=====\033[1;36m[  \033[1;35mConcact Me : +6283113611267\033[1;36m  ]\033[1;32m=====>
\033[1;32m    <=====\033[1;36m[   \033[1;35mYoutube.com/c/DarkCurut08   \033[1;36m]\033[1;32m=====>
\033[1;32m    <=====================\033[1;36m[]\033[1;32m====================>\n";
echo "1. Bukalapak  [ Spam WhatsApp ]" | lolcat
echo "2. Telkomsel  [ Spam SMS ]" | lolcat
echo "3. Grab       [ Spam Call ]" | lolcat
echo "4. Tokopedia  [ Spam Call ]" | lolcat
echo "5. Surveyon   [ Spam Email ]" | lolcat
echo "\033[31;1m0. Keluar"
read -p " [!] Pilih Nomernya => " dc08;

case $dc08 in

1) clear
php 1
;;

2) clear
php 2.php
;;

3) clear
php 3.php
;;


4) clear
php 4.php
;;

5) clear
php 6.php
;;

0) echo "\033[31;1m Keluar"
sleep 2
exit
;;

esac
done
done

